# Quantum reservoir robot policy

A trapped-ion-style quantum reservoir computer used as the memory of a robot controller. The reservoir is
benchmarked against classical baselines on a robot manipulation task, and the trained controller runs as
Qiskit circuits on Qollab's simulators.

This effort is supported by Qollab & IonQ.

## The problem

The task is Lift from the robomimic benchmark: a robot arm picks up a cube. From 100 human demonstrations, a
policy learns to turn the robot's 19 sensor values into its 7 action commands at every frame (imitation
learning). A good policy needs some memory of what happened in earlier frames.

A reservoir computer supplies that memory with fixed, untrained dynamics; only a linear readout is trained.
Here the dynamics are quantum:

1. The 19 observations are standardised and projected to one rotation angle per qubit (RY).
2. Every qubit gets an RZ rotation, and every pair of qubits an XX rotation with a fixed random strength.
3. Every qubit loses a fraction 0.3 of its excitation (amplitude damping), which makes old inputs fade.
4. The averages of Z and X on every qubit, and of ZZ and XX on every pair, are the features for the readout.

The state is carried from frame to frame within a demonstration. The question is how this compares with a
classical reservoir (echo state network) and a plain linear model, and whether it can run as circuits.

## Run it on Qollab

Press **Run**. `main.py` loads the trained 6-qubit policy from `lift_policy.npz` and does three things:

- It simulates the reservoir exactly along one held-out demonstration and prints the error against the human.
- It prints what `src/sweep.py` ran offline (its settings) and what that gave (MSE and MAE of every trained
  reservoir, from `src/results/sweep/results.json`), and draws the size sweep in the lower half of the figure.
- For a few frames it builds the same reservoir as a circuit, runs it on the selected backend, and recomputes
  the action from the measured counts. The figure shows the human (grey), the exact policy (blue) and the
  measured actions (orange dots).

| Backend | What is sent |
|---|---|
| Built-in simulator | 12 circuits of 7 qubits: 6 reservoir qubits and one ancilla, reset after every use |
| IonQ simulators | one circuit of 24 qubits, because IonQ backends have no reset and take one job per run |

Amplitude damping is built from gates: a controlled rotation moves part of each qubit's excitation onto an
ancilla. The Run settings are `shots`, `replay` (how many past frames each circuit replays; the reservoir
forgets older ones) and `every` (which frames are measured).

Tick `retrain` to train the reservoirs again inside the run instead of only reading the stored results. It
runs the code and data in `src/` (NumPy, in the browser): every classical reservoir, the quantum reservoirs up
to `max_qubits`, and the policy of the demo. The retrained scores are printed next to the stored ones and
marked with rings in the figure. Up to 6 qubits takes seconds on a laptop; 8 qubits takes longer, and 10 or 12
are better run offline with `src/sweep.py`.

## Results

Test loss is the mean squared error against the human's actions on 15 held-out demonstrations (lower is better).

| Model | Features | Adam readout | Exact (ridge) readout |
|---|---|---|---|
| Classical reservoir, 10 nodes | 10 | 0.0565 | 0.0564 |
| Classical reservoir, 20 nodes | 20 | 0.0481 | 0.0478 |
| Classical reservoir, 50 nodes | 50 | 0.0459 | 0.0456 |
| Classical reservoir, 100 nodes | 100 | 0.0376 | 0.0370 |
| Quantum reservoir, 4 qubits | 20 | 0.0985 | 0.0834 |
| Quantum reservoir, 6 qubits | 42 | 0.0605 | 0.0590 |
| Quantum reservoir, 8 qubits | 72 | 0.0521 | 0.0483 |
| Quantum reservoir, 10 qubits | 110 | 0.0503 | 0.0453 |
| Quantum reservoir, 12 qubits | 156 | 0.0474 | 0.0432 |

For reference, always predicting the average action gives 0.1740 and a linear model on the current
observation gives 0.0448.

![Test error against reservoir size](src/results/sweep/size_sweep.png)

- The quantum reservoir improves steadily with size and reaches the linear model at 10 to 12 qubits.
- The 100-node classical reservoir is clearly ahead. We found no quantum advantage on this task.
- The policy in the Qollab demo also shows the readout the current observation. It scores 0.0430, and 0.0439
  when its features are measured with 1,000 shots.

Limits of these numbers: one random reservoir per size and 15 test demonstrations, so small gaps between rows
are within noise. The Adam readout has not fully converged for the quantum reservoirs. The error is measured
against the human's actions; the policy was not run in the robot simulator, so there is no success rate.

## Files

There are two files called `main.py`. The one at the top is what Qollab runs. `src/main.py` is the PyTorch
training script.

| File | What it does | Needs |
|---|---|---|
| `main.py` | Qollab entry point: runs the trained policy as circuits | Qollab |
| `lift_policy.npz` | the trained policy and one held-out demonstration | |
| `src/sweep.py` | trains both reservoirs at every size (the table above) | NumPy |
| `src/sweep_plots.ipynb` | plots the size sweep | NumPy, Matplotlib |
| `src/train_readout.py` | makes `lift_policy.npz` from the 6-qubit reservoir of the sweep | NumPy |
| `src/main.py` | trains one configuration | PyTorch, Qiskit |
| `src/reservoirs.py`, `src/utils.py` | the reservoir models and training code for `src/main.py` | PyTorch, Qiskit |
| `src/reservoirs_numpy.py`, `src/utils_numpy.py`, `src/main_numpy.py` | NumPy copies of the models, and evaluation of saved parameter files | NumPy |
| `src/video_data.py` | dataset loading, split and normalisation | NumPy |
| `src/scaling_tuned.py`, `src/scaling_core_all_w2.py` | tuned comparison across sets of measured observables | PyTorch, Qiskit, Matplotlib |
| `src/reservoir_training.ipynb` | training curves for one configuration | PyTorch, Qiskit |
| `src/dataset/` | `final_dataset.pkl` and the notebook that makes it | h5py, pandas for the notebook |
| `src/results/sweep/` | scores (`results.json`), trained parameters and the figure of the size sweep | |
| `tests/` | unit tests | |

`src/README.md` has the developer notes for the training code.

## Reproduce it

```
pip install -r requirements.txt
cd src
python sweep.py            # the size sweep; the 12-qubit run took about 90 minutes on a laptop
python train_readout.py    # writes lift_policy.npz
```

`sweep.py` skips runs that are already in `src/results/sweep/results.json`, so delete that folder to start
again. `requirements_torch.txt` adds what the PyTorch scripts need and `requirements_notebook.txt` what the
notebooks need.

To rebuild `final_dataset.pkl`, download robomimic's Lift dataset (proficient-human, low-dimensional,
`low_dim_v15.hdf5`) into `src/dataset/` and run `dataset_generation.ipynb`. The file is 21 MB and is not kept
in this repository.

## How it was checked

- The simulation in `sweep.py` gives the same features as `reservoirs_numpy.QuantumReservoir` to 13 decimal
  places, and the same test scores as a parameter file exported by `src/main.py` to 9 decimal places.
- The fast simulation in `scaling_tuned.py` gives the same results as the Qiskit reservoir in
  `src/reservoirs.py` to 7 decimal places on a reduced run.
- `python -m unittest tests.test_numpy tests.test_variable_videos` runs the NumPy tests from the top folder.

## Credits and disclosure

- **Data:** the Lift demonstrations come from robomimic (Mandlekar et al., "What Matters in Learning from
  Offline Human Demonstrations for Robot Manipulation", CoRL 2021), recorded in the robosuite simulator.
  `src/dataset/final_dataset.pkl` and the demonstration inside `lift_policy.npz` are derived from that data,
  which belongs to its authors and is not covered by this repository's licence.
- **Libraries:** Qiskit, NumPy, Matplotlib and PyTorch.
- **Background:** quantum reservoir computing was introduced by Fujii and Nakajima, "Harnessing
  Disordered-Ensemble Quantum Dynamics for Machine Learning", Phys. Rev. Applied 8, 024030 (2017).
- **AI assistance:** code and analysis were developed with the help of AI assistants (Claude and ChatGPT).
  The team ran and checked the results.
- **Build window:** all code here was written during the hackathon, 9 to 11 October 2026.

The code is released under the MIT licence (see `LICENSE`).
